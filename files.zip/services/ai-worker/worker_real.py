"""
AI Worker integrated with free/open-source libraries:
- Segment Anything (SAM) for segmentation (mask)
- Diffusers (Stable Diffusion) for image-to-image background generation

Behaviour:
- If required libraries & models are available, runs real pipeline parts.
- If not available or GPU missing, falls back to placeholder outputs (as before).
- Uploads results to S3/MinIO and returns asset metadata.

Environment variables used:
- REDIS_URL, S3_ENDPOINT, S3_ACCESS_KEY, S3_SECRET_KEY, S3_BUCKET
- HF_TOKEN (optional) - Hugging Face token to pull models
- SAM_CHECKPOINT (optional path to local checkpoint for SAM)
- SD_MODEL_ID (e.g., "runwayml/stable-diffusion-v1-5" or another HF model)
"""

import os
import time
import json
import traceback
from io import BytesIO
from PIL import Image, ImageDraw
import requests
import boto3

# try to import heavy libs
HAS_TORCH = False
HAS_DIFFUSERS = False
HAS_SAM = False
try:
    import torch
    HAS_TORCH = True
    from diffusers import StableDiffusionImg2ImgPipeline
    HAS_DIFFUSERS = True
except Exception as e:
    print("Diffusers/torch not available:", e)

try:
    # segment-anything package from GitHub
    from segment_anything import SamAutomaticMaskGenerator, sam_model_registry
    HAS_SAM = True
except Exception as e:
    print("SAM not available:", e)

# S3 client
s3_endpoint = os.getenv('S3_ENDPOINT', 'http://minio:9000')
s3_key = os.getenv('S3_ACCESS_KEY', 'minioadmin')
s3_secret = os.getenv('S3_SECRET_KEY', 'minioadmin')
bucket = os.getenv('S3_BUCKET', 'adify')

s3 = boto3.client('s3',
                  aws_access_key_id=s3_key,
                  aws_secret_access_key=s3_secret,
                  endpoint_url=s3_endpoint,
                  region_name='us-east-1')

def upload_bytes(key, data, content_type='image/jpeg'):
    try:
        s3.create_bucket(Bucket=bucket)
    except Exception:
        pass
    s3.put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    return f"{s3_endpoint}/{bucket}/{key}"

def make_placeholder_image(text='placeholder', size=(1200,800), color=(240,240,240)):
    im = Image.new('RGB', size, color)
    d = ImageDraw.Draw(im)
    d.text((20,20), text, fill=(40,40,40))
    buf = BytesIO()
    im.save(buf, format='JPEG')
    buf.seek(0)
    return buf.read()

# Utility: download an S3/HTTP image
def download_image(url):
    # if local S3 endpoint pattern, use direct HTTP GET
    if url.startswith('http'):
        r = requests.get(url)
        r.raise_for_status()
        return Image.open(BytesIO(r.content)).convert('RGB')
    raise ValueError("Unsupported image url: " + url)

# SAM segmentation function (if available)
def run_sam_segmentation(pil_image):
    """
    Returns a single binary mask (PIL) for the dominant product area.
    Requires HAS_SAM True and SAM_CHECKPOINT env var or accessible HF model.
    """
    if not HAS_SAM:
        raise RuntimeError("SAM not available")
    # prepare
    checkpoint = os.getenv('SAM_CHECKPOINT')
    if not checkpoint:
        raise RuntimeError("SAM_CHECKPOINT env var must point to a SAM checkpoint path")

    # load SAM model (this may take time & memory)
    print("Loading SAM model from", checkpoint)
    device = "cuda" if HAS_TORCH and torch.cuda.is_available() else "cpu"
    try:
        sam = sam_model_registry["vit_h"](checkpoint=checkpoint)
    except Exception:
        # fallback to generic key if above fails
        sam = sam_model_registry.get("default", list(sam_model_registry.keys())[0])(checkpoint=checkpoint)
    sam.to(device=device)
    mask_generator = SamAutomaticMaskGenerator(sam)
    image_np = np.array(pil_image)
    masks = mask_generator.generate(image_np)
    if not masks:
        raise RuntimeError("SAM produced no masks")
    # choose largest mask
    largest = max(masks, key=lambda m: m['area'])
    mask_arr = np.zeros(image_np.shape[:2], dtype='uint8')
    mask_arr[largest['segmentation']] = 255
    mask_pil = Image.fromarray(mask_arr).convert('L')
    return mask_pil

# Stable Diffusion image-to-image background generator (if available)
def generate_backgrounds_with_sd(init_image_pil, prompt, n=3, strength=0.65, guidance=7.5):
    """
    Uses Hugging Face diffusers StableDiffusionImg2ImgPipeline to generate n backgrounds.
    Returns list of PIL images.
    """
    if not HAS_DIFFUSERS or not HAS_TORCH:
        raise RuntimeError("diffusers/torch not available")
    model_id = os.getenv('SD_MODEL_ID', 'runwayml/stable-diffusion-v1-5')
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.float16 if device == "cuda" else torch.float32

    print(f"Loading SD model {model_id} on {device} (dtype={dtype})")
    pipe = StableDiffusionImg2ImgPipeline.from_pretrained(model_id, torch_dtype=dtype)
    pipe.to(device)
    results = []
    # prepare init image as PIL resized to reasonable resolution
    init_image = init_image_pil.copy()
    # ensure 512-ish large but not huge
    init_image = init_image.resize((768, 512))
    for i in range(n):
        out = pipe(prompt=prompt, image=init_image, strength=strength, guidance_scale=guidance, num_inference_steps=20)
        img = out.images[0].convert('RGB')
        results.append(img)
    return results

# High-level handlers (used by job dispatcher)
def handle_segment(job_payload):
    project_id = job_payload.get('projectId')
    # in job_payload expect original image url in params.original_url
    original_url = job_payload.get('params', {}).get('original_url')
    if not original_url:
        return {'error': 'original_url missing'}

    try:
        im = download_image(original_url)
    except Exception as e:
        print("Failed to download image:", e)
        return {'error': str(e)}

    # try run SAM if available, else fallback to placeholder mask
    try:
        if HAS_SAM:
            import numpy as np
            mask_pil = run_sam_segmentation(im)
            buf = BytesIO()
            mask_pil.save(buf, format='PNG')
            buf.seek(0)
            key = f"projects/{project_id}/mask-{int(time.time())}.png"
            upload_bytes(key, buf.getvalue(), content_type='image/png')
            return {'asset': {'type': 'mask', 'key': key, 'url': f"{s3_endpoint}/{bucket}/{key}"}}
        else:
            # fallback: create coarse mask by thresholding brightness (not accurate)
            gray = im.convert('L')
            mask = gray.point(lambda p: 255 if p < 250 else 0)
            buf = BytesIO()
            mask.save(buf, format='PNG')
            key = f"projects/{project_id}/mask-fallback-{int(time.time())}.png"
            upload_bytes(key, buf.getvalue(), content_type='image/png')
            return {'asset': {'type': 'mask', 'key': key, 'url': f"{s3_endpoint}/{bucket}/{key}", 'note': 'fallback mask'}}
    except Exception as e:
        traceback.print_exc()
        # fallback placeholder
        data = make_placeholder_image('mask-failed-'+project_id, (800,800))
        key = f"projects/{project_id}/mask-error-{int(time.time())}.jpg"
        upload_bytes(key, data)
        return {'asset': {'type': 'mask', 'key': key, 'url': f"{s3_endpoint}/{bucket}/{key}", 'error': str(e)}}

def handle_scene_gen(job_payload):
    project_id = job_payload.get('projectId')
    params = job_payload.get('params', {})
    style = params.get('style', 'studio')
    original_url = params.get('original_url')
    prompt = f"A {style} background for a product photo, clean composition, soft studio lighting, high quality"
    try:
        if original_url and HAS_DIFFUSERS:
            init_img = download_image(original_url)
            imgs = generate_backgrounds_with_sd(init_img, prompt, n=3)
            urls = []
            for idx, img in enumerate(imgs):
                buf = BytesIO()
                img.save(buf, format='JPEG', quality=92)
                key = f"projects/{project_id}/background-{style}-{idx}.jpg"
                upload_bytes(key, buf.getvalue(), content_type='image/jpeg')
                urls.append(f"{s3_endpoint}/{bucket}/{key}")
            return {'backgrounds': urls}
        else:
            # fallback placeholders
            urls = []
            for i in range(3):
                data = make_placeholder_image(f'{style}-{i}', (1200,900))
                key = f"projects/{project_id}/background-{style}-{i}.jpg"
                upload_bytes(key, data)
                urls.append(f"{s3_endpoint}/{bucket}/{key}")
            note = 'generated placeholders (diffusers unavailable or original_url missing)'
            return {'backgrounds': urls, 'note': note}
    except Exception as e:
        traceback.print_exc()
        # fallback placeholders
        urls = []
        for i in range(3):
            data = make_placeholder_image(f'{style}-err-{i}', (1200,900))
            key = f"projects/{project_id}/background-{style}-err-{i}.jpg"
            upload_bytes(key, data)
            urls.append(f"{s3_endpoint}/{bucket}/{key}")
        return {'backgrounds': urls, 'error': str(e)}

def handle_poses(job_payload):
    # For MVP: reuse scene_gen to create 6 pose-like images if SD available,
    # but true pose-conditioned generation requires ControlNet / OpenPose templates.
    project_id = job_payload.get('projectId')
    original_url = job_payload.get('params', {}).get('original_url')
    try:
        if original_url and HAS_DIFFUSERS:
            init_img = download_image(original_url)
            # crude approach: generate variations using different prompts tailored to poses
            pose_prompts = [
                "Product on a model, frontal pose, studio lighting",
                "Product held by hand, lifestyle shot, warm light",
                "Side profile pose, minimal background",
                "Action shot, model walking, motion blur",
                "Close-up detail shot, soft bokeh",
                "Editorial full-body pose, luxury setting"
            ]
            urls = []
            for i, p in enumerate(pose_prompts):
                imgs = generate_backgrounds_with_sd(init_img, p, n=1, strength=0.8)
                img = imgs[0]
                buf = BytesIO()
                img.save(buf, format='JPEG', quality=92)
                key = f"projects/{project_id}/pose-{i}.jpg"
                upload_bytes(key, buf.getvalue(), content_type='image/jpeg')
                urls.append(f"{s3_endpoint}/{bucket}/{key}")
            # make collage (simple horizontal concat)
            # load last images and stitch
            images = [Image.open(BytesIO(requests.get(u).content)).convert('RGB') for u in urls]
            widths, heights = zip(*(i.size for i in images))
            total_w = sum(widths)
            max_h = max(heights)
            collage = Image.new('RGB', (total_w, max_h), (255,255,255))
            x_offset = 0
            for im in images:
                collage.paste(im, (x_offset, 0))
                x_offset += im.width
            buf = BytesIO()
            collage.save(buf, format='JPEG', quality=90)
            keyc = f"projects/{project_id}/collage-{int(time.time())}.jpg"
            upload_bytes(keyc, buf.getvalue(), content_type='image/jpeg')
            return {'poses': urls, 'collage': f"{s3_endpoint}/{bucket}/{keyc}"}
        else:
            # fallback placeholders
            urls = []
            for i in range(6):
                data = make_placeholder_image(f'pose-{i}', (1200,1600))
                key = f"projects/{project_id}/pose-{i}.jpg"
                upload_bytes(key, data)
                urls.append(f"{s3_endpoint}/{bucket}/{key}")
            collage = make_placeholder_image('collage', (1800,1200))
            keyc = f"projects/{project_id}/collage.jpg"
            upload_bytes(keyc, collage)
            return {'poses': urls, 'collage': f"{s3_endpoint}/{bucket}/{keyc}", 'note': 'placeholders'}
    except Exception as e:
        traceback.print_exc()
        # fallback placeholder branch
        urls = []
        for i in range(6):
            data = make_placeholder_image(f'pose-err-{i}', (1200,1600))
            key = f"projects/{project_id}/pose-err-{i}.jpg"
            upload_bytes(key, data)
            urls.append(f"{s3_endpoint}/{bucket}/{key}")
        collage = make_placeholder_image('collage-err', (1800,1200))
        keyc = f"projects/{project_id}/collage-err.jpg"
        upload_bytes(keyc, collage)
        return {'poses': urls, 'collage': f"{s3_endpoint}/{bucket}/{keyc}", 'error': str(e)}

# Copy generator remains a lightweight stub (LLM integration optional)
def handle_copy(job_payload):
    product_name = job_payload.get('params', {}).get('product_name', 'منتج')
    headlines = [f"{product_name} — عنوان {i}" for i in range(1,6)]
    descriptions = [f"وصف قصير {i} لـ{product_name}" for i in range(1,4)]
    ctas = ["اشتري الآن", "اعرف المزيد", "احصل ��لى خصم", "اطلب اليوم", "تسوق الآن", "أضف إلى السلة", "احجز", "اطلب الآن", "اطلب الآن", "اطلب الآن"]
    hashtags = [f"#{product_name.replace(' ','')}{i}" for i in range(1,21)]
    return {'headlines': headlines, 'descriptions': descriptions, 'ctas': ctas[:10], 'hashtags': hashtags}

# Dispatcher wrapper for external queue (keeps same interface as earlier stub)
def process_job(payload):
    jtype = payload.get('jobType')
    try:
        if jtype == 'segment':
            return handle_segment(payload)
        if jtype == 'scene_gen':
            return handle_scene_gen(payload)
        if jtype == 'poses':
            return handle_poses(payload)
        if jtype == 'copy':
            return handle_copy(payload)
        return {'ok': True, 'note': 'unknown job type'}
    except Exception as e:
        traceback.print_exc()
        return {'error': str(e)}

# When run directly (for local testing), process sample jobs from env or loop
if __name__ == '__main__':
    # simple test loop (not an RQ worker); you can integrate with RQ/Redis as before.
    print("Worker (real) test mode. HAS_TORCH:", HAS_TORCH, "HAS_DIFFUSERS:", HAS_DIFFUSERS, "HAS_SAM:", HAS_SAM)
    # Basic local smoke test if env provides ORIGINAL_TEST_URL and PROJECT_ID
    test_url = os.getenv('ORIGINAL_TEST_URL')
    pid = os.getenv('TEST_PROJECT_ID', 'local-test')
    if test_url:
        print("Running sample segment job...")
        out = handle_segment({'projectId': pid, 'params': {'original_url': test_url}})
        print("Segment output:", out)
        print("Running sample scene_gen job...")
        out2 = handle_scene_gen({'projectId': pid, 'params': {'original_url': test_url, 'style': 'studio'}})
        print("Scene gen output keys:", out2.keys())
    else:
        print("No ORIGINAL_TEST_URL set — worker is ready to be wired to your queue (RQ/Bull) by calling process_job(payload).")