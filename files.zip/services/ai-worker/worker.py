"""
AI Worker (stub) — consumes jobs from Redis queue (RQ)
Replace stub functions with real model integrations:
- segmentation: call SAM or a hosted inference endpoint
- scene_gen: call Stable Diffusion with ControlNet (background only)
- poses: generate model images via SD + controlnet, or call external try-on service
- copy: call OpenAI/GPT with prompt templates

This worker demonstrates the pipeline and stores generated dummy images to S3 (MinIO).
"""
import os
import time
import json
from rq import Connection, Queue, Worker
import redis
import boto3
from PIL import Image, ImageDraw
from io import BytesIO

redis_url = os.getenv('REDIS_URL', 'redis://redis:6379')
s3_endpoint = os.getenv('S3_ENDPOINT', 'http://minio:9000')
s3_key = os.getenv('S3_ACCESS_KEY', 'minioadmin')
s3_secret = os.getenv('S3_SECRET_KEY', 'minioadmin')
bucket = os.getenv('S3_BUCKET', 'adify')

conn = redis.from_url(redis_url)
q = Queue('adify-jobs', connection=conn)

s3 = boto3.client('s3',
                  aws_access_key_id=s3_key,
                  aws_secret_access_key=s3_secret,
                  endpoint_url=s3_endpoint,
                  region_name='us-east-1')

def upload_bytes(key, data, content_type='image/png'):
    try:
        s3.create_bucket(Bucket=bucket)
    except:
        pass
    s3.put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    return f"{s3_endpoint}/{bucket}/{key}"

def make_placeholder_image(text='placeholder', size=(1200,800), color=(240,240,240)):
    im = Image.new('RGB', size, color)
    d = ImageDraw.Draw(im)
    d.text((20,20), text, fill=(40,40,40))
    buf = BytesIO()
    im.save(buf, format='JPEG')
    buf.seek(0)
    return buf.read()

# Pipeline task handlers (stubs)
def handle_segment(job_payload):
    project_id = job_payload.get('projectId')
    print("SEGMENT: project", project_id)
    # Create dummy mask image and upload
    data = make_placeholder_image('mask-'+project_id, (800,800))
    key = f"projects/{project_id}/mask-{int(time.time())}.jpg"
    url = upload_bytes(key, data)
    return {'asset': {'type': 'mask', 'key': key, 'url': url}}

def handle_scene_gen(job_payload):
    project_id = job_payload.get('projectId')
    style = job_payload.get('params', {}).get('style', 'studio')
    print("SCENE GEN:", project_id, style)
    urls = []
    for i in range(3):
        data = make_placeholder_image(f'{style}-{i}', (1200,900))
        key = f"projects/{project_id}/background-{style}-{i}.jpg"
        upload_bytes(key, data)
        urls.append(f"{s3_endpoint}/{bucket}/{key}")
    return {'backgrounds': urls}

def handle_poses(job_payload):
    project_id = job_payload.get('projectId')
    urls = []
    for i in range(6):
        data = make_placeholder_image(f'pose-{i}', (1200,1600))
        key = f"projects/{project_id}/pose-{i}.jpg"
        upload_bytes(key, data)
        urls.append(f"{s3_endpoint}/{bucket}/{key}")
    # generate collage
    collage = make_placeholder_image('collage', (1800,1200))
    keyc = f"projects/{project_id}/collage.jpg"
    upload_bytes(keyc, collage)
    return {'poses': urls, 'collage': f"{s3_endpoint}/{bucket}/{keyc}"}

def handle_copy(job_payload):
    # Return mock copy
    product = job_payload.get('params', {}).get('product_name', 'منتج')
    headlines = [f"{product} - عنوان {i}" for i in range(1,6)]
    descriptions = [f"وصف قصير {i} ل{product}" for i in range(1,4)]
    ctas = ["اشترِ الآن","تعرّف أكثر","سجّل للحصول على خصم","اضف إلى السلة","تسوّق الآن","احصل عليه","اطلب اليوم","اطلب الآن","تسوّق وادخر","احصل على العرض"]
    hashtags = [f"#{product.replace(' ','')}{i}" for i in range(1,21)]
    return {'headlines': headlines, 'descriptions': descriptions, 'ctas': ctas[:10], 'hashtags': hashtags}

# Main dispatcher (used by RQ jobs)
def process_job(payload):
    print("Processing job:", payload)
    jtype = payload.get('jobType')
    if jtype == 'segment':
        return handle_segment(payload)
    if jtype == 'scene_gen':
        return handle_scene_gen(payload)
    if jtype == 'poses':
        return handle_poses(payload)
    if jtype == 'copy':
        return handle_copy(payload)
    # fallback
    return {'ok': True}

if __name__ == '__main__':
    with Connection(conn):
        worker = Worker(['adify-jobs'], connection=conn)
        print("Worker started, waiting for jobs...")
        worker.work()