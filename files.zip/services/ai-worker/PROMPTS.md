# Prompts & Integration notes

Segmentation (SAM)
- Input: original image (S3 URL)
- Prompt: Use SAM with bounding box from a quick object detector (YOLO) to extract the product mask. Return PNG alpha. Post-processing via MODNet matting.

Scene generation (Stable Diffusion)
- Prompt template:
  "A {style} photo background for a {category} product, high-fashion editorial lighting, soft shadows, color palette: {brand_colors}, minimal text, high resolution"
- Use ControlNet (Canny) for layout if needed. Generate 3 variants.

Pose model generation
- For non-wearables: generate hands-holding poses and overlay original product pixels (paste + harmonize).
- For apparel: try-on pipeline using deepfashion or image2image with pose skeletons. Use texture-preservation: paste original pattern via texture transfer.

Copy generation (LLM)
- Prompt template includes brand tone (brand_kit), product features extracted via vision or user input, platform target, and compliance rules (no medical claims).
- Output structured JSON: {headlines:[...], descriptions:[...], ctas:[...], hashtags:[...]}.

Partial regenerate
- Store seeds and params for each asset; re-run individual jobs referencing same mask/product crop.

Ad Compliance
- Run classifier on generated text; if flagged, mark for manual review.
