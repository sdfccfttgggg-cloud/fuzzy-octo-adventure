'use client'
import { useCallback, useState } from 'react'
import axios from 'axios'

export default function UploadDropzone({ onCreated }: { onCreated?: (id:string)=>void }) {
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)

  const onFile = useCallback((f: File) => setFile(f), [])
  const submit = async () => {
    if (!file) return
    setLoading(true)
    try {
      // Create project
      const create = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/api/projects`, {
        name: `Project ${Date.now()}`,
        category: 'unknown'
      })
      const projectId = create.data.id
      // upload file
      const fd = new FormData()
      fd.append('file', file)
      const up = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/api/projects/${projectId}/upload`, fd, { headers: { 'Content-Type': 'multipart/form-data' }})
      onCreated?.(projectId)
      // kick segmentation job
      await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/api/projects/${projectId}/jobs`, {
        job_type: 'segment',
        params: {}
      })
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <div className="border-2 border-dashed p-8 rounded text-center">
        <input id="file" type="file" accept="image/*" onChange={(e)=> e.target.files && onFile(e.target.files[0])} />
        {file && <p className="mt-2">Selected: {file.name}</p>}
      </div>
      <div className="mt-4">
        <button disabled={!file || loading} className="bg-indigo-600 text-white px-4 py-2 rounded" onClick={submit}>{loading ? 'جاري...' : 'ابدأ التوليد'}</button>
      </div>
    </div>
  )
}