export default function Home() {
  return (
    <div className="space-y-6">
      <section className="bg-white p-8 rounded shadow">
        <h2 className="text-3xl font-bold">حول Adify Studio</h2>
        <p className="mt-4">حوّل صورة منتج إلى باك إعلان كامل تلقائياً: صور موديل، خلفيات، نصوص، وصفحات هبوط وتصدير ZIP جاهز.</p>
        <div className="mt-6">
          <a href="/studio" className="bg-indigo-600 text-white px-4 py-2 rounded">ابدأ الآن</a>
        </div>
      </section>

      <section className="grid grid-cols-3 gap-4">
        <div className="p-6 bg-white rounded shadow">Feature: Product Lock</div>
        <div className="p-6 bg-white rounded shadow">Feature: Auto Backgrounds</div>
        <div className="p-6 bg-white rounded shadow">Feature: Model Styling</div>
      </section>
    </div>
  )
}