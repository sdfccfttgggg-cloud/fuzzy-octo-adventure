'use client'
import { useState } from 'react'
import UploadDropzone from '../../components/UploadDropzone'

export default function StudioPage() {
  const [projectId, setProjectId] = useState<string| null>(null)
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Studio — ارفع صورة المنتج</h2>
      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white p-6 rounded shadow">
          <UploadDropzone onCreated={(id) => setProjectId(id)} />
        </div>
        <aside className="bg-white p-6 rounded shadow">
          <h3 className="font-semibold">Settings</h3>
          <div className="mt-4">
            <label className="block">نوع المنتج</label>
            <select className="mt-1 block w-full border rounded p-2">
              <option>ملابس</option>
              <option>عطر</option>
              <option>ساعة</option>
              <option>شنطة</option>
            </select>
          </div>
          <div className="mt-4">
            <label>ستايل الإعلان</label>
            <select className="mt-1 block w-full border rounded p-2">
              <option>Luxury</option>
              <option>Minimal</option>
              <option>Street</option>
              <option>Beauty</option>
              <option>Sport</option>
            </select>
          </div>
        </aside>
      </div>

      {projectId && (
        <div className="bg-white p-4 rounded shadow">
          <p>Project created: {projectId} — اذهب إلى صفحة المشروع للمراجعة</p>
          <a href={`/projects/${projectId}`} className="text-indigo-600 underline">عرض المشروع</a>
        </div>
      )}
    </div>
  )
}