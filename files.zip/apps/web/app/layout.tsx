import './styles/globals.css'
export const metadata = { title: 'Adify Studio' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-gray-50 text-gray-800">
        <header className="bg-white shadow p-4">
          <div className="max-w-6xl mx-auto flex justify-between">
            <h1 className="font-bold text-xl">Adify Studio</h1>
            <nav>
              <a href="/" className="px-3">الصفحة الرئيسية</a>
              <a href="/studio" className="px-3">Studio</a>
              <a href="/projects" className="px-3">Projects</a>
            </nav>
          </div>
        </header>
        <main className="max-w-6xl mx-auto p-6">{children}</main>
      </body>
    </html>
  )
}