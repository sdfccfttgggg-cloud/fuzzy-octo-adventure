API Gateway notes:
- Run `npm install` then `npm run dev`
- Prisma: run `npx prisma generate` and `npx prisma migrate dev --name init` (or see docker-compose which runs dev server)
- API endpoints:
  POST /api/projects { name, category } -> { id }
  POST /api/projects/:id/upload (multipart/form-data file)
  POST /api/projects/:id/jobs { job_type, params }