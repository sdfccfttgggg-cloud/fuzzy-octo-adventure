import AWS from 'aws-sdk'
const endpoint = process.env.S3_ENDPOINT || 'http://minio:9000'
const s3 = new AWS.S3({
  endpoint,
  accessKeyId: process.env.S3_ACCESS_KEY,
  secretAccessKey: process.env.S3_SECRET_KEY,
  s3ForcePathStyle: true,
})

export async function uploadToS3(key: string, body: Buffer, contentType = 'application/octet-stream') {
  const bucket = process.env.S3_BUCKET || 'adify'
  await s3.createBucket({ Bucket: bucket }).promise().catch(()=>{})
  await s3.putObject({ Bucket: bucket, Key: key, Body: body, ContentType: contentType }).promise()
  return { key }
}