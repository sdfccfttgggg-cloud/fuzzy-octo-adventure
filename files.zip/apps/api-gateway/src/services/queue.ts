import { Queue, Worker } from 'bullmq'
import IORedis from 'ioredis'
const connection = new IORedis(process.env.REDIS_URL || 'redis://redis:6379')
export const jobQueue = new Queue('adify-jobs', { connection })

export async function enqueueJob(payload: any) {
  const job = await jobQueue.add('job', payload, { attempts: 3 })
  return job.id
}

// Note: Worker will be consumed by Python worker (or you can implement JS worker). For demo, JS worker is not added here.