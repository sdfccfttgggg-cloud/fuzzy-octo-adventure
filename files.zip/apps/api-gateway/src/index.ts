import express from 'express'
import cors from 'cors'
import bodyParser from 'body-parser'
import projectRouter from './routes/projects'

const app = express()
app.use(cors())
app.use(bodyParser.json())
app.use('/api/projects', projectRouter)

app.get('/health', (req, res) => res.json({ ok: true }))
const port = process.env.PORT || 4000
app.listen(port, () => console.log(`API listening on ${port}`))