import express from 'express'
import multer from 'multer'
import { v4 as uuid } from 'uuid'
import { uploadToS3 } from '../services/s3'
import { enqueueJob } from '../services/queue'

const router = express.Router()
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } })

// In-memory store for demo (replace with DB calls / Prisma)
const projects: Record<string, any> = {}

router.post('/', (req, res) => {
  const id = uuid()
  projects[id] = { id, ...req.body, assets: [], createdAt: new Date().toISOString() }
  res.json({ id })
})

router.get('/:id', (req, res) => {
  const p = projects[req.params.id]
  if (!p) return res.status(404).json({ error: 'not found' })
  res.json(p)
})

router.post('/:id/upload', upload.single('file'), async (req, res) => {
  const buf = req.file?.buffer
  if (!buf) return res.status(400).json({ error: 'file required' })
  const key = `projects/${req.params.id}/original-${Date.now()}.jpg`
  await uploadToS3(key, buf, req.file?.mimetype || 'image/jpeg')
  // store asset reference
  projects[req.params.id].assets.push({ id: uuid(), type: 'original', key, url: `/s3/${key}` })
  res.json({ url: `/s3/${key}` })
})

router.post('/:id/jobs', async (req, res) => {
  const { job_type, params } = req.body
  const jobId = await enqueueJob({ projectId: req.params.id, jobType: job_type, params })
  res.json({ jobId })
})

export default router