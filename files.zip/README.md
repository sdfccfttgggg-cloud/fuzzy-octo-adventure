```markdown
# Adify Studio — Monorepo (MVP scaffold)

This repo is a starter scaffold for "Adify Studio" — a system to convert a single product image into a full Ad Pack.

Services:
- apps/web (Next.js + Tailwind) — frontend
- apps/api-gateway (Express + Prisma) — backend API
- services/ai-worker (Python) — job worker (stubs for segmentation/generation)
- infra: docker-compose (Postgres, Redis, MinIO)

Quickstart (local)
1. Copy `.env.example` to `.env` and edit credentials.
2. Build & run:
   ```bash
   docker-compose up --build
   ```
3. Open:
   - Frontend: http://localhost:3000
   - API: http://localhost:4000
   - MinIO Console: http://localhost:9001 (credentials in .env)
   - Redis: 6379
   - Postgres: 5432

Notes
- AI functions are stubs in `services/ai-worker/worker.py`. Replace with integration to SAM / Stable Diffusion / ControlNet / OpenAI as required.
- DB migrations use Prisma (see apps/api-gateway/prisma).
- Storage uses MinIO as S3-compatible for local dev; replace with real S3 in production.

Important files overview
- prisma/schema.prisma — DB schema mapping (users, projects, assets, jobs, brand_kits, ad_packs)
- apps/api-gateway/src/routes/* — API endpoints (projects, uploads, jobs, exports)
- apps/web — NextJS app with pages: /, /studio, project view
- services/ai-worker/worker.py — Worker consumes RQ jobs and executes pipeline steps (stubs)
- PROMPTS.md — suggested prompts for segmentation/composition/copy generation

Acceptance Criteria (MVP)
- Upload image and create project
- Run segmentation job → mask asset saved
- Generate 3 background variations and 6 pose images (stubs produce mock images)
- Generate copy using LLM (stub returns examples)
- Export ZIP containing platform folders + manifest.json + landing.html

For production
- Replace stubs with real model calls (consider using separate GPU machines).
- Harden auth (OAuth/JWT), billing, RBAC, file retention & cleanup, monitoring.
- Add tests, CI, and cloud infra (EKS/Render/Vercel + managed Postgres/S3).

```